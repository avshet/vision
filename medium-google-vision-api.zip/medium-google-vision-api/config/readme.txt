1. Put your own Google Service Account keyFile.json in this folder.
2. Push the whole project to Heroku.
3. Run command line -- heroku config:set GOOGLE_APPLICATION_CREDENTIALS='config/keyFile.json'

For more information, please see the Medium post.

